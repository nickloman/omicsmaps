DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
    },
}

INSTALLED_APPS = (
    "django.contrib.sites",
    "override_settings",
)
